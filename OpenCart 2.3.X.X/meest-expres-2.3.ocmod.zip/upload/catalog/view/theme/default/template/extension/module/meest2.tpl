<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>
    .meest2-container {
        margin: 15px 0;
        padding: 15px;
        background: #f8f9fa;
        border: 1px solid #e0e0e0;
        border-radius: 8px;
    }

    .meest2-field-wrapper {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 15px;
    }

    .meest2-field-wrapper:last-child {
        margin-bottom: 0;
    }

    .meest2-input-group {
        flex: 1;
        max-width: 50%;
    }

    .meest2-input-group label {
        display: block;
        margin-bottom: 5px;
        font-weight: 500;
        color: #333;
        font-size: 14px;
    }

    .meest2-input-group input {
        width: 100%;
        padding: 10px 15px;
        border: 1px solid #ddd;
        border-radius: 6px;
        font-size: 14px;
        transition: border-color 0.3s;
    }

    .meest2-input-group input:focus {
        outline: none;
        border-color: #4CAF50;
    }

    .meest2-input-group input:disabled {
        background-color: #f5f5f5;
        cursor: not-allowed;
    }

    .meest2-map-btn {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 10px 20px;
        background: #2196F3;
        color: white;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-size: 14px;
        font-weight: 500;
        text-decoration: none;
        transition: background 0.3s;
        white-space: nowrap;
        align-self: flex-end;
    }

    .meest2-map-btn:hover {
        background: #1976D2;
        color: white;
        text-decoration: none;
    }

    .meest2-map-btn svg {
        width: 20px;
        height: 20px;
    }

    .meest2-map-btn.hidden {
        display: none;
    }

    /* Модальное окно */
    .meest2-modal {
        display: none;
        position: fixed;
        z-index: 9999;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        animation: fadeIn 0.3s;
    }

    .meest2-modal.active {
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .meest2-modal-content {
        background-color: #fff;
        border-radius: 8px;
        width: 90%;
        max-width: 1000px;
        height: 80vh;
        max-height: 600px;
        position: relative;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        animation: slideIn 0.3s;
    }

    .meest2-modal-header {
        padding: 20px;
        border-bottom: 1px solid #e0e0e0;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .meest2-modal-header h3 {
        margin: 0;
        font-size: 18px;
        font-weight: 500;
    }

    .meest2-modal-close {
        background: none;
        border: none;
        font-size: 28px;
        cursor: pointer;
        color: #666;
        padding: 0;
        width: 30px;
        height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: color 0.3s;
    }

    .meest2-modal-close:hover {
        color: #000;
    }

    .meest2-modal-body {
        padding: 0;
        height: calc(100% - 70px);
    }

    .meest2-modal-body iframe {
        width: 100%;
        height: 100%;
        border: none;
        border-radius: 0 0 8px 8px;
    }

    #meest2-map {
        width: 100%;
        height: 100%;
        border-radius: 0 0 8px 8px;
    }

    .meest2-loading {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100%;
        font-size: 16px;
        color: #666;
    }




    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }

    @keyframes slideIn {
        from {
            transform: translateY(-50px);
            opacity: 0;
        }
        to {
            transform: translateY(0);
            opacity: 1;
        }
    }

    @media (max-width: 768px) {
        .meest2-field-wrapper {
            flex-direction: column;
            align-items: stretch;
        }

        .meest2-input-group {
            max-width: 100%;
        }

        .meest2-map-btn {
            margin-top: 10px;
            width: 100%;
            justify-content: center;
        }
    }
</style>
<script>

    if (!window.meest2Loaded) {
        window.meest2Loaded = true;


        $(document).on('change', 'input[type="radio"][name="shipping_method"]', function () {
            const self = this;

            setTimeout(function () {
                const val = $(self).val();

                $('.data-meest').remove();

                if (val.indexOf('meest2.') !== -1) {

                    meest2();
                }
            }, 1200);
        });


        const meestDelivery = ["meest2.courier", "meest2.postomat", "meest2.warehouse"];

        // ====== helper: обновление всех полей checkout ======
        function updateCheckoutFields(city, address) {
            if (city !== null) {
                $('input[name="shipping_address[city]"]').each(function () {
                    $(this).val(city).attr('value', city).trigger('change');
                });
            }
            if (address !== null) {
                $('input[name="shipping_address[address_1]"]').each(function () {
                    $(this).val(address).attr('value', address).trigger('change');
                });
            }
        };


        function meest2() {
            const active_ship = $('input[type="radio"][name="shipping_method"]:checked');
            const meest_service = active_ship.val();

            if (meestDelivery.indexOf(meest_service) !== -1) {
                if (meest_service === 'meest2.postomat') {
                    const {branchAddress, inputCity} = renderInputs(
                        'postomat',
                        `<?php echo $text_meest2_postomat; ?>`,
                        `<?php echo $text_meest2_search_city; ?>`
                    );
                    active_ship.parent().after(inputCity);


                    const address = '',
                        city = '',
                        cityId = '',
                        input = $('input[data-meest=postomat]');

                    if (address && city) {
                        $('input[data-meest=city]').val(city).attr('value', city).attr('data-city-id', cityId);
                        input
                            .val(address)
                            .attr('value', address)
                            .attr('data-city-id', cityId)
                            .removeAttr('disabled');

                        saveAddress(city, address);

                        // Показываем кнопку карты если город заполнен
                        $('.meest2-container[data-meest=postomat-container] .meest2-map-btn').removeClass('hidden');

                        // обновляем checkout поля
                        updateCheckoutFields(item['city'], null);
                        updateCheckoutFields(null, item['address']);
                    }

                    if (address && cityId) {
                        place('postomat');
                    }

                    $('span[data-meest=postomat] input').on('change', function () {
                        $('#input-shipping-address-1').val($(this).val());
                        saveAddress(city, $(this).val());

                        // обновляем все поля shipping_address[address_1]
                        updateCheckoutField('address_1', $(this).val());
                    });
                } else if (meest_service === 'meest2.warehouse') {
                    const {branchAddress, inputCity} = renderInputs(
                        'warehouse',
                        `<?php echo $text_meest2_warehouse; ?>`,
                        `<?php echo $text_meest2_search_city; ?>`
                    );
                    active_ship.parent().after(inputCity);

                    const address = '',
                        city = '',
                        cityId = '',
                        input = $('input[data-meest=warehouse]');

                    if (address && city) {
                        $('input[data-meest=city]').val(city).attr('value', city).attr('data-city-id', cityId);
                        input
                            .val(address)
                            .attr('value', address)
                            .attr('data-city-id', cityId)
                            .removeAttr('disabled');

                        saveAddress(city, address);

                        // Показываем кнопку карты если город заполнен
                        $('.meest2-container[data-meest=warehouse-container] .meest2-map-btn').removeClass('hidden');

                        // обновляем checkout поля
                        updateCheckoutFields(item['city'], null);
                        updateCheckoutFields(null, item['address']);
                    }

                    if (address && cityId) {
                        place('warehouse');
                    }

                    $('span[data-meest=warehouse] input').on('change', function () {
                        $('#input-shipping-address-1').val($(this).val());
                        saveAddress(city, $(this).val());

                        // обновляем все поля shipping_address[address_1]
                        updateCheckoutField('address_1', $(this).val());
                    });
                } else if (meest_service === 'meest2.courier') {
                    const container = `
                    <div class="data-meest meest2-container" data-meest="courier-container">
                        <div class="meest2-field-wrapper">
                            <div class="meest2-input-group">
                                <label><?php echo $text_meest2_search_city; ?></label>
                                <input id="meestCity" type="text" class="form-control" placeholder="<?php echo $text_meest2_search_city; ?>"/>
                            </div>
                        </div>
                        <div class="meest2-field-wrapper">
                            <div class="meest2-input-group">
                                <label><?php echo $text_meest2_courier; ?></label>
                                <input disabled id="meestAddress" type="text" class="form-control" placeholder="<?php echo $text_meest2_courier; ?>"/>
                            </div>
                        </div>
                    </div>
                `;
                    active_ship.parent().after(container);

                    let address = '',
                        city = '',
                        cityId = '',
                        input = $('#meestAddress');

                    if (address && city) {
                        input.removeAttr('disabled');
                        $('#meestCity').val(city).attr('value', city);
                        input.val(address).attr('value', address).attr('data-city-id', cityId);

                        saveAddress(city, address);

                        // обновляем checkout поля
                        updateCheckoutFields(item['city'], null);
                        updateCheckoutFields(null, item['address']);
                    }

                    if (cityId) {
                        input.removeAttr('disabled');
                    }

                    input.on('change', function () {
                        $('#input-shipping-address-1').val(`${meest_service}_address`, $(this).val());
                        saveAddress(`${$('#meestCity').val()}`, `${$(this).val()}`);

                        // обновляем checkout поля
                        updateCheckoutField('address_1', $(this).val());
                    });
                }

                let element,
                    m_service = meest_service.split('.'),
                    m_serv = m_service[1],
                    name = '';
                if (m_serv === 'warehouse') {
                    name = `<?php echo $text_title_warehouse; ?>`
                } else if (m_serv === 'postomat') {
                    name = `<?php echo $text_title_postomat; ?>`
                }

                const input = $('input[data-meest=' + m_serv + ']');

                $(input).autocomplete({
                    'source': function (request, response) {
                        const cityName = $('input[data-meest="city"]').val(),
                            value = input.val(),
                            savedBranch = '';

                        if (value !== savedBranch || value.length === 0) {
                            const cityId = input.attr('data-city-id');
                            $.ajax({
                                url: 'index.php?route=extension/module/meest2/getMeestData',
                                type: 'POST',
                                data: {
                                    action: m_serv === 'postomat' ? 'getPoshtomat' : 'getBranches',
                                    filter: cityId,
                                    search: request
                                },
                                dataType: 'json',
                                success: function (json) {
                                    response($.map(json, function (item) {
                                        return {
                                            label: item['description'],
                                            address: item['description'],
                                            value: item['id'],
                                            place: ''
                                        }
                                    }));
                                }
                            });
                        }
                    },
                    'select': function (item) {
                        input.val(item['address']).attr('data-address', item['address']);

                        // Логика с координатами закомментирована
                        // const mapBtn = $(`#meest-map-link-${m_serv}`);
                        // if (item['place']) {
                        //     mapBtn.attr('href', 'https://www.google.com/maps/' + item['place']);
                        //     localStorage.setItem(`${meest_service}_place`, item['place']);
                        // } else {
                        //     const city = localStorage.getItem(`${meest_service}_city`);
                        //     const searchQuery = encodeURIComponent(`${city}, ${item['address']}`);
                        //     mapBtn.attr('href', `https://www.google.com/maps/search/?api=1&query=${searchQuery}`);
                        // }

                        const city = $('input[data-meest="city"]').val();
                        const cityId = $('input[data-meest="city"]').attr('data-city-id');

                        saveAddress(city, item['address']);

                        // Розраховуємо ціну доставки після вибору відділення
                        if (cityId && item['value']) {
                            calculateAndUpdateShippingPrice(m_serv, cityId, item['value']);
                        }

                        // вставляем И город И адрес во все поля чекаута после выбора отделения
                        updateCheckoutFields(city, item['address']);
                    }
                });

                // Показываем кнопку карты при заполнении города
                $('input[data-meest=city]').on('input change', function () {
                    const cityValue = $(this).val().trim();
                    const mapBtn = $(this).closest('.meest2-container').find('.meest2-map-btn');

                    if (cityValue.length > 0) {
                        mapBtn.removeClass('hidden');
                    } else {
                        mapBtn.addClass('hidden');
                    }
                });

                $('input[data-meest=city]').autocomplete({
                    'source': function (request, response) {
                        element = $(this);

                        const disabled = input.attr('disabled'),
                            value = $('input[data-meest=city]').val(),
                            savedCityId = '';

                        if (!disabled && request.length < 1) {
                            input
                                .attr('disabled', true)
                                .attr('data-city-id', null)
                                .attr('value', '')
                                .val('');
                            $('#meest-tmp').remove();
                        }

                        if (value !== savedCityId) {
                            input
                                .attr('disabled', true)
                                .attr('data-city-id', null)
                                .attr('value', '')
                                .val('');
                            $('#meest-tmp').remove();

                            $.ajax({
                                url: 'index.php?route=extension/module/meest2/getMeestData',
                                type: 'POST',
                                data: {
                                    action: 'getCities',
                                    filter: '',
                                    search: request
                                },
                                dataType: 'json',
                                success: function (json) {
                                    response($.map(json, function (item) {
                                        return {
                                            label: item['type'] + ' ' + item['name'] + ', ' + item['region'],
                                            city: item['name'],
                                            value: item['id'],
                                        }
                                    }));
                                }
                            });
                        }
                    },
                    'select': function (item) {
                        element
                            .val(item['city'])
                            .attr('value', item['city'])
                            .attr('data-address', item['city'])
                            .attr('data-city-id', item['value']);

                        input.removeAttr('disabled').attr('data-city-id', item['value']);

                        input.val('').attr('value', '').attr('data-address', '');
                        $('#meest-tmp').remove();

                        // Показываем кнопку карты после выбора города
                        const mapBtn = element.closest('.meest2-container').find('.meest2-map-btn');
                        mapBtn.removeClass('hidden');

                        // НЕ заполняем поле города сразу - ждем выбора отделения
                    }
                });

                $('#meestCity').autocomplete({
                    'source': function (request, response) {
                        element = $(this);

                        const disabled = element.attr('disabled'),
                            value = element.val(),
                            savedCityId = '';

                        if (!disabled && request.length < 1) {
                            $('#meestAddress')
                                .attr('disabled', true)
                                .attr('data-city-id', null)
                                .attr('value', '')
                                .val('');
                        }

                        if (request.length > 2 && value !== savedCityId) {
                            $.ajax({
                                url: 'index.php?route=extension/module/meest2/getMeestData',
                                type: 'POST',
                                data: {
                                    action: 'getCities',
                                    filter: '',
                                    search: request
                                },
                                dataType: 'json',
                                success: function (json) {
                                    response($.map(json, function (item) {
                                        return {
                                            label: item['type'] + ' ' + item['name'] + ', ' + item['region'],
                                            value: item['id'],
                                        }
                                    }));
                                }
                            });
                        }
                    },
                    'select': function (item) {
                        if (item['value']) {
                            element.val(item['label']).attr('value', item['label']);

                            $('#meestAddress').removeAttr('disabled').attr('data-city-id', item['value']);

                            // Показываем кнопку карты после выбора города (для courier)
                            const mapBtn = element.closest('.meest2-container').find('.meest2-map-btn');
                            if (mapBtn.length) {
                                mapBtn.removeClass('hidden');
                            }

                            // НЕ заполняем поле города сразу - ждем выбора улицы
                        } else {
                            element.val('');
                        }
                    }
                });

                $('#meestAddress').autocomplete({
                    'source': function (request, response) {
                        element = $(this);
                        const cityId = $(element).attr('data-city-id');

                        if (request.length > 0) {
                            $.ajax({
                                url: 'index.php?route=extension/module/meest2/getMeestData',
                                type: 'POST',
                                data: {
                                    action: 'getStreets',
                                    filter: cityId,
                                    search: request
                                },
                                dataType: 'json',
                                success: function (json) {
                                    response($.map(json, function (item) {
                                        return {
                                            label: item['description'],
                                            value: item['description'],
                                        }
                                    }));
                                }
                            });
                        }
                    },
                    'select': function (item) {
                        element
                            .val(item['label'])
                            .attr('data-value', item['label'])
                            .attr('value', item['label'])
                            .focus();

                        const city = $('#meestCity').val();
                        const cityId = $('#meestCity').attr('data-city-id') || element.attr('data-city-id');

                        saveAddress(city, element.val());

                        // Розраховуємо ціну доставки після вибору адреси для courier
                        if (cityId && item['value']) {
                            calculateAndUpdateShippingPrice('courier', cityId, item['value']);
                        }

                        // вставляем И город И улицу в поля checkout после выбора улицы
                        updateCheckoutFields(city, element.val());
                    }
                });
            }
        }

        function saveAddress(city, address) {
            $.post(
                'index.php?route=extension/module/meest2/save',
                {
                    city: city,
                    address: address
                }
            );
        }

        /**
         * Розрахунок та оновлення ціни доставки через API
         * @param {string} service - Тип сервісу (warehouse, postomat, courier)
         * @param {string} cityUUID - UUID міста отримувача
         * @param {string} addressUUID - UUID відділення або адреси (обов'язковий)
         */
        function calculateAndUpdateShippingPrice(service, cityUUID, addressUUID) {
            if (!cityUUID || !addressUUID) {
                console.warn('Meest2: City UUID and Address/Branch UUID are required for price calculation');
                return;
            }

            // Мапінг сервісів до типів доставки API
            const serviceMapping = {
                'warehouse': 'Branch',
                'postomat': 'Branch',
                'courier': 'Door'
            };

            const receiverService = serviceMapping[service] || 'Branch';

            // Формуємо параметри для розрахунку
            const params = {
                receiver_city_id: cityUUID,
                receiver_service: receiverService
            };

            // Додаємо UUID відділення для warehouse і postomat
            if ((service === 'warehouse' || service === 'postomat') && addressUUID) {
                params.receiver_branch_id = addressUUID;
            }

            // Додаємо UUID адреси для courier
            if (service === 'courier' && addressUUID) {
                params.receiver_address_id = addressUUID;
            }

            // Показуємо індикатор завантаження
            const priceElement = $('#meest2-price-' + service);
            if (priceElement.length) {
                const originalText = priceElement.text();
                priceElement.html('<span style="opacity: 0.5;">Розрахунок...</span>');

                // Відправляємо AJAX-запит на розрахунок
                $.ajax({
                    url: 'index.php?route=extension/module/meest2/calculateShippingCost',
                    type: 'POST',
                    data: params,
                    dataType: 'json',
                    success: function (response) {
                        if (response && response.success && response.data && (typeof response.data.costServices !== 'undefined')) {
                            const costInUAH = parseFloat(response.data.costServices) || 0;

                            const formattedPrice = (costInUAH <= 0)
                                ? 0
                                : costInUAH.toFixed(2) + ' ₴';

                            priceElement.html(formattedPrice);
                            priceElement.attr('data-cost', costInUAH);
                            priceElement.attr('data-cost-with-tax', costInUAH);

                            console.log('Meest2: Price updated for ' + service + ': ' + formattedPrice);
                        } else {
                            priceElement.html(originalText);
                            console.warn('Meest2: Failed to calculate price', response);
                        }
                    },
                    error: function (xhr, status, error) {
                        // При помилці повертаємо оригінальний текст
                        priceElement.html(originalText);
                        console.error('Meest2: AJAX error', error);
                    }
                });
            }
        }

        function place(type) {
            // Логика с координатами закомментирована
            // let place = localStorage.getItem(`meest2.${type}_place`);
            // const mapBtn = $(`#meest-map-link-${type}`);
            // if (place) {
            //     mapBtn.attr('href', 'https://www.google.com/maps/' + place);
            // }
        }

        function renderInputs(type, textInputBranch, textInputCity) {
            let container = `
            <div class="data-meest meest2-container" data-meest="${type}-container">
                <div class="meest2-field-wrapper">
                    <div class="meest2-input-group">
                        <label>${textInputCity}</label>
                        <input type="text" class="form-control"  data-meest="city" placeholder="${textInputCity}"/>
                    </div>
                </div>
                <div class="meest2-field-wrapper">
                    <div class="meest2-input-group">
                        <label>${textInputBranch}</label>
                        <input disabled type="text" class="form-control"  data-meest="${type}" placeholder="${textInputBranch}"/>
                    </div>
                    <a href="#" class="meest2-map-btn hidden" id="meest-map-link-${type}" data-map-url="https://www.google.com/maps/search/?api=1&query=Ukraine">
                        <svg viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
                        </svg>
                        Обрати на мапі
                    </a>
                </div>
            </div>
        `;

            return {
                branchAddress: '',
                inputCity: container
            }
        }

        let meest2Map = null;
        let meest2Markers = [];

        // Обработчик для открытия модального окна
        $(document).on('click', '.meest2-map-btn', function (e) {
            e.preventDefault();

            const $btn = $(this);
            const container = $btn.closest('.meest2-container');
            const type = container.attr('data-meest').replace('-container', '');
            const cityId = container.find('input[data-meest=city]').attr('data-city-id');

            if (!cityId) {
                alert('<?php echo $text_meest2_search_city; ?>');
                return;
            }

            // Создаем модальное окно если его еще нет
            if ($('#meest2-map-modal').length === 0) {
                const modal = `
                <div id="meest2-map-modal" class="meest2-modal">
                    <div class="meest2-modal-content">
                        <div class="meest2-modal-header">
                            <h3><?php echo $text_meest2_map; ?></h3>
                            <button class="meest2-modal-close" id="meest2-modal-close">&times;</button>
                        </div>
                        <div class="meest2-modal-body">
                            <div id="meest2-map"></div>
                        </div>
                    </div>
                </div>
            `;
                $('body').append(modal);
            }

            // Показываем модальное окно
            $('#meest2-map-modal').addClass('active');

            // Загружаем отделения и отображаем на карте
            loadBranchesOnMap(cityId, type, container);
        });

        function loadBranchesOnMap(cityId, type, container) {
            $('#meest2-map').html('<div class="meest2-loading">Завантаження...</div>');

            $.ajax({
                url: 'index.php?route=extension/module/meest2/getBranchesWithCoordinates',
                type: 'POST',
                data: {
                    city_id: cityId,
                    type: type
                },
                dataType: 'json',
                success: function (branches) {
                    if (branches.length === 0) {
                        $('#meest2-map').html('<div class="meest2-loading">Відділення не знайдено</div>');
                        return;
                    }

                    // Очищаем контейнер
                    $('#meest2-map').html('');

                    // Удаляем старую карту если существует
                    if (meest2Map) {
                        meest2Map.remove();
                        meest2Map = null;
                        meest2Markers = [];
                    }

                    // Создаем новую карту
                    meest2Map = L.map('meest2-map').setView([50.4501, 30.5234], 13);

                    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                        attribution: '&copy; OpenStreetMap contributors'
                    }).addTo(meest2Map);

                    // Добавляем маркеры
                    const bounds = [];
                    branches.forEach(function (branch) {
                        if (branch.latitude && branch.longitude) {
                            const lat = parseFloat(branch.latitude);
                            const lng = parseFloat(branch.longitude);
                            bounds.push([lat, lng]);

                            const marker = L.marker([lat, lng]).addTo(meest2Map);
                            marker.bindPopup(`
                            <div style="min-width: 200px;">
                                <strong>${branch.description}</strong><br>
                                ${branch.address}<br>
                                <button class="btn btn-primary btn-sm" style="margin-top: 10px;"
                                        onclick="selectBranch('${branch.id}', '${branch.address.replace(/'/g, "\\'")}')"
                                >Обрати</button>
                            </div>
                        `);

                            meest2Markers.push(marker);
                            }
                                    });

                    // Центрируем карту по маркерам
                    if (bounds.length > 0) {
                        meest2Map.fitBounds(bounds, {padding: [50, 50]});
                    }

                    // Обновляем размер карты
                    setTimeout(function () {
                        meest2Map.invalidateSize();
                    }, 100);
                },
                error: function () {
                    $('#meest2-map').html('<div class="meest2-loading">Помилка завантаження</div>');
                }
            });
        }

        // Функция выбора отделения на карте
        window.selectBranch = function (branchId, branchAddress) {
            const activeContainer = $('.meest2-container:visible').last();
            const type = activeContainer.attr('data-meest').replace('-container', '');
            const input = activeContainer.find(`input[data-meest=${type}]`);

            // Заполняем поле
            input.val(branchAddress).attr('value', branchAddress);

            const meest_service = 'meest2.' + type;
            const city = activeContainer.find('input[data-meest=city]').val();
            const cityId = activeContainer.find('input[data-meest=city]').attr('data-city-id');

            // Сохраняем на сервере
            saveAddress(city, branchAddress);

            // Обновляем скрытое поле
            $('#input-shipping-address-1').val(branchAddress);

            // вставляем И город И адрес во все поля checkout после выбора на карте
            updateCheckoutFields(city, branchAddress);

            // Розраховуємо ціну доставки після вибору відділення на карті
            if (cityId && branchId) {
                calculateAndUpdateShippingPrice(type, cityId, branchId);
            }

            // Закрываем модальное окно
            $('#meest2-map-modal').removeClass('active');
        };

        // Закрытие модального окна по крестику
        $(document).on('click', '#meest2-modal-close', function () {
            $('#meest2-map-modal').removeClass('active');
        });

        // Закрытие модального окна по клику вне его
        $(document).on('click', '#meest2-map-modal', function (e) {
            if (e.target.id === 'meest2-map-modal') {
                $('#meest2-map-modal').removeClass('active');
            }
        });

        if (typeof $.fn.autocomplete == 'function') {
            meest2();
        } else {
            document.addEventListener('DOMContentLoaded', function () {
                meest2();
            })
        }

    }
</script>

