(function ($) {
    var methods = {
        init: function (options) {
            return this.each(function () {
                var $this = $(this);
                var data = $this.data('meestAutocomplete');

                if (!data) {
                    $this.timer = null;
                    $this.items = new Array();
                    $.extend($this, options);
                    $this.attr('autocomplete', 'new-password');

                    // On focus, request autocomplete data
                    $this.on('focus.meestAutocomplete', function () {
                        $this.request('');
                    });

                    // On blur, hide the autocomplete list after a delay
                    $this.on('blur.meestAutocomplete', function () {
                        setTimeout(function (object) {
                            object.hide();
                        }, 200, $this);
                    });

                    // On keydown, handle escape key and start autocomplete request
                    $this.on('keydown.meestAutocomplete', function (event) {
                        switch (event.keyCode) {
                            case 27: // escape
                                $this.hide();
                                break;
                            default:
                                $this.request();
                                break;
                        }
                    });

                    // Click event handler for autocomplete items
                    $this.click = function (event) {
                        event.preventDefault();
                        var id = $(event.target).parent().attr('data-id');
                        var value = $(event.target).parent().attr('data-value');
                        if (value && $this.items[id]) {
                            $this.select($this.items[id]);
                        }
                    };

                    // Show autocomplete list below the input
                    $this.show = function () {
                        var pos = $this.position();
                        $this.siblings('ul.' + $this.class).css({
                            'top': pos.top + $this.outerHeight(),
                            'left': pos.left
                        });
                        $this.siblings('ul.' + $this.class).show();
                    };

                    // Hide the autocomplete list
                    $this.hide = function () {
                        $this.siblings('ul.' + $this.class).hide();
                    };

                    // Request autocomplete data (with a delay)
                    $this.request = function (search) {
                        clearTimeout($this.timer);
                        $this.timer = setTimeout(function (object) {
                            search = (typeof(search) === 'undefined') ? object.val() : search;
                            object.source(search, $.proxy(object.response, object));
                        }, 200, $this);
                    };

                    // Handle autocomplete response data
                    $this.response = function (json) {
                        var html = '';
                        var i;
                        if (json.length) {
                            for (i = 0; i < json.length; i++) {
                                this.items[i] = json[i];
                                html += '<li data-id="' + i + '" city-id="' + json[i]['id'] + '" data-value="' + json[i]['value'] + '"><a href="#">' + json[i]['label'] + '</a></li>';
                            }
                        }
                        if (html && $this.is(':focus')) {
                            $this.show();
                        } else {
                            $this.hide();
                        }
                        $this.siblings('ul.' + $this.class).html(html);
                    };

                    $this.after('<ul class="' + $this.class + '"></ul>');
                    $this.siblings('ul.' + $this.class).delegate('a', 'click', $.proxy($this.click, $this));
                    $this.data('meestAutocomplete', true);
                }
            });
        },
        destroy: function () {
            return this.each(function () {
                var $this = $(this);
                $this.removeData('meestAutocomplete');
                $this.off('.meestAutocomplete');
            });
        }
    };

    $.fn.meestAutocomplete = function (method) {
        if (methods[method]) {
            return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
        } else if (typeof(method) === 'object' || !method) {
            return methods.init.apply(this, arguments);
        } else {
            $.error('Method "' + method + '" does not exist for jQuery.meestAutocomplete');
        }
    };
})(window.jQuery);

function saveAddress(cityUuid, address1Uuid, meestShippingMethod) {
    $.post('index.php?route=module/meest2/saveUuid', {
        cityUuid: cityUuid,
        addressUuid: address1Uuid,
        shippingMethod: meestShippingMethod
    });
}

let cityUuid = null;
let address1Uuid = null;
let meestShippingMethod = null;

// $(document).ready(function() {
//     $(document).on('click', '#button-guest, #button-payment-address, #button-shipping-address', function() {
//         saveAddress(cityUuid, address1Uuid, meestShippingMethod);
//     });
// });

// MeestShippingData object
function MeestShippingData() {
    var self = this;
    var src, method, lang, city;

    self.methods_meest = [
        'meest2.warehouse',
        'meest2.courier',
        'meest2.postomat'
    ];

    self.languages = {
        'en': {
            'shipping_method': 'Shipping method',
            'text_select': ' --- Select --- ',
            'meest_warehouse': 'Meest warehouse',
            'meest_courier': 'Meest courier',
            'meest_poshtomat': 'Meest postomat',
            'text_meest2_warehouse': 'Enter the department number or address (street, house number)',
            'text_meest2_postomat': 'Enter the number or address of the post office (street, house number)',
            'text_meest2_courier': 'Enter the street name and house/apartment number'
        },
        'uk': {
            'shipping_method': 'Спосіб доставки',
            'text_select': ' --- Оберіть --- ',
            'meest_warehouse': 'Відділення Meest',
            'meest_courier': 'Кур\'єром Meest на адресу',
            'meest_poshtomat': 'Поштомат Meest',
            'text_meest2_warehouse': 'Введіть номер або адресу відділення (вулиця, номер будинку)',
            'text_meest2_postomat': 'Введіть номер або адресу поштомату (вулиця, номер будинку)',
            'text_meest2_courier': 'Введіть назву вулиці та номер будинку/квартири'
        },
        'ru': {
            'shipping_method': 'Способ доставки',
            'text_select': ' --- Выберите --- ',
            'meest_warehouse': 'Отделение Meest',
            'meest_courier': 'Курьером Meest по адресу',
            'meest_poshtomat': 'Почтомат Meest',
            'text_meest2_warehouse': 'Введите номер или адрес отделения (улица, номер дома)',
            'text_meest2_postomat': 'Введите номер или адрес почтомата (улица, номер дома)',
            'text_meest2_courier': 'Введите название улицы и номер дома/квартиры'
        }
    };

    // Set current method and language
    self.setProp = function () {
        self.method = $('#input-shipping_method').val() || $('input[name="shipping_method"]:checked').val() || $('select[name="shipping_method"]').val();
        self.lang = $('html').attr('lang') || 'uk';
    };

    // Handle changes in zone, city, and shipping_method fields
    self.handlerChanges = function (name, value) {
        if (name.match(/zone/i)) {
            $('input[name*="city"]:visible').val('');
            $('input[name*="address_1"]:visible, input[name*="address_2"]:visible, input[name*="street"]:visible').val('');
        } else if (name.match(/city/i)) {
            $('input[name*="address_1"]:visible, input[name*="address_2"]:visible, input[name*="street"]:visible').val('');
        } else if (name.match(/shipping_method/i)) {
            $('input[name*="city"]:visible, input[name*="address_1"]:visible, input[name*="address_2"]:visible, input[name*="street"]:visible')
                .val('')
                .meestAutocomplete('destroy');
            self.method = value;
        }
    };

    // Get address data from backend (cities, branches, streets, etc.)
    self.getAddress = function (element, search) {
        var filter, action, filterZone;
        var currentMethod = $('#input-shipping_method').val() || $('input[name="shipping_method"]:checked').val() || $('select[name="shipping_method"]').val();
        // self.method = $('input[name="shipping_method"]:checked').val() || $('select[name="shipping_method"]').val();

        if (!self.methods_meest.includes(currentMethod)) {
            return $.Deferred().resolve([]).promise();
        }

        var actionMap = {
            'meest2.warehouse': 'getBranches',
            'meest2.courier': 'getStreets',
            'meest2.postomat': 'getPoshtomat'
        };

        if (element[0].name.match(/city/i)) {
            // If the element is for city field
            action = 'getCities';
            filter = $('[name*="zone"]:visible').val() || '';
        } else if (element[0].name.match(/address_1|address_2|street/i)) {
            // For address fields, determine action based on current method
            action = actionMap[currentMethod] || 'getBranches';
            // Using self.cityFilter instead of extracting from DOM
            // filter = self.cityFilter;
            filter = self.city || '';
            if (!filter) {
                return $.Deferred().resolve([]).promise();
            }
        }

        if (!search) {
            search = element[0].value;
        }

        return $.ajax({
            url: 'index.php?route=module/meest2/getMeestData',
            type: 'POST',
            data: {
                action: action,
                filter: encodeURIComponent(filter),
                search: encodeURIComponent(search)
            },
            dataType: 'json',
            global: false,
            success: function (json) {
                self.src = json;
            }
        });
    };
}

// On DOM ready
$(function () {
    var meestShippingData = new MeestShippingData();
    meestShippingData.setProp();

    $('input[name="city"]').val('');
    $('input[name="address_1"]').val('');

    // Update properties after any AJAX completion
    $(document).ajaxStop(function () {
        meestShippingData.setProp();
    });

    $(document).on('change', '[name="shipping_method"]', function (e) {
        var shippingMethod = $(this).val();
        if (!shippingMethod.startsWith('meest')) {
            $('input[name="address_1"]').val('');
            $('ul.dropdown-address').empty();
            $('input[name="address_1"]').meestAutocomplete('destroy');
        }
    });

    // When AJAX requests for register/guest/payment_address are completed, insert shipping method select
    $(document).ajaxSuccess(function (ev, xhr, settings) {
        $(document).on('change', '#input-shipping_method', function () {
            var shippingMethod = $('#input-shipping_method').val();
            meestShippingMethod = shippingMethod;
            if (shippingMethod && shippingMethod.indexOf('meest2.') !== -1) {
                $('#input-payment-postcode').closest('.form-group').hide();
                $('input[name*="city"]:visible').val('').meestAutocomplete('destroy');
                $('input[name*="address_1"]:visible, input[name*="address_2"]:visible, input[name*="street"]:visible').val('').meestAutocomplete('destroy');
            } else {
                $('#input-payment-postcode').closest('.form-group').show();

                $('input[name*="city"]:visible').val('').meestAutocomplete('destroy');
                $('input[name*="address_1"]:visible, input[name*="address_2"]:visible, input[name*="street"]:visible').val('').meestAutocomplete('destroy');
            }
        });

        if (settings.url.includes('register') || settings.url.includes('guest') || settings.url.includes('payment_address')) {

            $('div.form-group > #input-shipping_method').parent().remove();

            $(document).ready(function () {
                $(document).ajaxComplete(function () {
                    if ($('div.form-group > label[for*="company"]').closest('.form-group').find('.col-sm-10').length > 0) {
                        const labelForShipping = $('div.form-group > label[for="input-shipping_method"]');
                        if (labelForShipping.length > 0) {
                            const selectElement = $('#input-shipping_method');
                            if (selectElement.length > 0) {
                                if (selectElement.find(`option[value="${meestShippingData.methods_meest[0]}"]`).length === 0 &&
                                    selectElement.find(`option[value="${meestShippingData.methods_meest[1]}"]`).length === 0 &&
                                    selectElement.find(`option[value="${meestShippingData.methods_meest[2]}"]`).length === 0) {
                                    selectElement.append(`
                                                    <option value="${meestShippingData.methods_meest[0]}">${meestShippingData.languages[meestShippingData.lang].meest_warehouse}</option>
                                                    <option value="${meestShippingData.methods_meest[1]}">${meestShippingData.languages[meestShippingData.lang].meest_courier}</option>
                                                    <option value="${meestShippingData.methods_meest[2]}">${meestShippingData.languages[meestShippingData.lang].meest_poshtomat}</option>
                                                `);
                                }
                            }
                        } else {
                            $('div.form-group > label[for*="company"]').closest('div.form-group').before(`
                                            <div class="form-group">
                                                <label class="control-label" for="input-shipping_method">
                                                    ${meestShippingData.languages[meestShippingData.lang].shipping_method}
                                                </label>
                                                  <select name="shipping_method" id="input-shipping_method" class="form-control">
                                                      <option value="">Select</option>
                                                      <option value="${meestShippingData.methods_meest[0]}">${meestShippingData.languages[meestShippingData.lang].meest_warehouse}</option>
                                                      <option value="${meestShippingData.methods_meest[1]}">${meestShippingData.languages[meestShippingData.lang].meest_courier}</option>
                                                      <option value="${meestShippingData.methods_meest[2]}">${meestShippingData.languages[meestShippingData.lang].meest_poshtomat}</option>
                                                  </select>
                                            </div>
                              `);
                        }
                    } else {
                        const labelForShipping = $('div.form-group > label[for="input-shipping_method"]');
                        if (labelForShipping.length > 0) {
                            const selectElement = $('#input-shipping_method');
                            if (selectElement.length > 0) {
                                if (selectElement.find(`option[value="${meestShippingData.methods_meest[0]}"]`).length === 0 &&
                                    selectElement.find(`option[value="${meestShippingData.methods_meest[1]}"]`).length === 0 &&
                                    selectElement.find(`option[value="${meestShippingData.methods_meest[2]}"]`).length === 0) {
                                    selectElement.append(`
                                                    <option value="${meestShippingData.methods_meest[0]}">${meestShippingData.languages[meestShippingData.lang].meest_warehouse}</option>
                                                    <option value="${meestShippingData.methods_meest[1]}">${meestShippingData.languages[meestShippingData.lang].meest_courier}</option>
                                                    <option value="${meestShippingData.methods_meest[2]}">${meestShippingData.languages[meestShippingData.lang].meest_poshtomat}</option>
                                                `);
                                }
                            }
                        } else {
                            $('div.form-group > label[for*="company"]').closest('div.form-group').before(`
                                            <div class="form-group">
                                                <label class="control-label" for="input-shipping_method">
                                                    ${meestShippingData.languages[meestShippingData.lang].shipping_method}
                                                </label>
                                                <select name="shipping_method" id="input-shipping_method" class="form-control">
                                                    <option value="">Select</option>
                                                    <option value="${meestShippingData.methods_meest[0]}">${meestShippingData.languages[meestShippingData.lang].meest_warehouse}</option>
                                                    <option value="${meestShippingData.methods_meest[1]}">${meestShippingData.languages[meestShippingData.lang].meest_courier}</option>
                                                    <option value="${meestShippingData.methods_meest[2]}">${meestShippingData.languages[meestShippingData.lang].meest_poshtomat}</option>
                                                </select>
                                            </div>
                                        `);
                        }
                    }
                });
            });
        }
    });

    // Handle changes in zone, city, shipping method
    /* Need retest
      $(document).on('change', '[name*="zone"]:visible, [name*="city"]:visible, [name*="shipping_method"]', function (e) {
          if(e.target.name === 'shipping_method') {
              if (e.target.value === '') {
                  $('label[for="input-payment-address-1"]').text(`{{ entry_address_1 }}`);
                  $('label[for="input-shipping-address-1"]').text(`{{ entry_address_1 }}`);
                  $('#input-shipping-postcode').closest('.form-group').show();
              } else {
                  $('label[for="input-payment-address-1"]').text(`${meestShippingData.languages[meestShippingData.lang]['text_' + e.target.value.replace(/\./g, '_')]}`);
                  $('label[for="input-shipping-address-1"]').text(`${meestShippingData.languages[meestShippingData.lang]['text_' + e.target.value.replace(/\./g, '_')]}`);
                  $('#input-shipping-postcode').closest('.form-group').hide();
              }
          }

          meestShippingData.handlerChanges(e.target.name, e.target.value);
      });
      */
    // Autocomplete for city
    $('body').on('focus', 'input[name*="city"]:visible', function () {
        if (this.name.match(/city/i)) {
            // var currentMethod = $('input[name="shipping_method"]:checked').val() || $('select[name="shipping_method"]').val();
            var currentMethod = $('#input-shipping_method').val() || $('#input-shipping_method').val() || $('input[name="shipping_method"]:checked').val() || $('select[name="shipping_method"]').val();

            var methods_meestA = [
                'meest2.warehouse',
                'meest2.courier',
                'meest2.postomat'
            ];

            if (!methods_meestA.includes(currentMethod)) {
                meestShippingData.src = [];
                return $.Deferred().resolve([]).promise();
            }

            meestShippingData.src = [];
            $(this).meestAutocomplete({
                source: function (request, response) {
                    meestShippingData.getAddress(this, request).done(function () {
                        if (Array.isArray(meestShippingData.src) && meestShippingData.src.length > 0) {
                            response($.map(meestShippingData.src, function (item) {
                                let regionPart = item['region'] ? ', обл. ' + item['region'] : '';
                                let typeC = item['type'] ? item['type'] + ' ' : '';
                                let label = typeC + item['name'] + regionPart;
                                return {
                                    id: item['id'] || '',
                                    label: label,
                                    value: item['name'],
                                    region_name: item['region'],
                                    type: item['type']
                                };
                            }));
                        } else {
                            response([]);
                        }
                    });
                },
                select: function (e) {
                    this.val(e.label);
                    this.attr('data-city-uuid', e.id);
                    cityUuid = e.id;
                    saveAddress(cityUuid, address1Uuid, currentMethod);
                    meestShippingData.city = e.id;
                    meestShippingData.cityFilter = e.id;
                    this.trigger('change');
                },
                class: 'dropdown-address'
            });
        }
    });

    // Autocomplete for address_1 (e.g., branches)
    $('body').on('focus', 'input[name*="address_1"]:visible', function () {
        if (this.name.match(/address_1/i)) {
            var cityValue = $('input[name*="city"]:visible').val();
            if (cityValue && cityValue.trim() !== '') {
                // var currentMethod = $('input[name="shipping_method"]:checked').val() || $('select[name="shipping_method"]').val();
                var currentMethod = $('#input-shipping_method').val() || $('#input-shipping_method').val() || $('input[name="shipping_method"]:checked').val() || $('select[name="shipping_method"]').val();
                var methods_meestA = [
                    'meest2.warehouse',
                    'meest2.courier',
                    'meest2.postomat'
                ];

                if (!methods_meestA.includes(currentMethod)) {
                    meestShippingData.src = [];
                    return $.Deferred().resolve([]).promise();
                }
                meestShippingData.src = [];

                $(this).meestAutocomplete({
                    source: function (request, response) {
                        meestShippingData.getAddress(this, request).done(function () {
                            if (Array.isArray(meestShippingData.src) && meestShippingData.src.length > 0) {
                                response($.map(meestShippingData.src, function (item) {
                                    let fullLabel = item['description'] ? item['description'].trim() : '';

                                    return {
                                        id: item['id'] || '',
                                        label: fullLabel,
                                        value: fullLabel
                                    };
                                }));
                            } else {
                                response([]);
                            }
                        });
                    },
                    select: function (e) {
                        this.val(e.value);
                        this.attr('data-address1-uuid', e.id);
                        address1Uuid = e.id;
                        saveAddress(cityUuid, address1Uuid, currentMethod);
                        this.trigger('change');
                    },
                    class: 'dropdown-address'
                });
            }
        }
    });

    // Autocomplete for address_2 or street
    $('body').on('focus', 'input[name*="address_2"]:visible, input[name*="street"]:visible', function () {
        if (this.name.match(/address_2|street/i)) {
            var currentMethod = $('input[name="shipping_method"]:checked').val() || $('select[name="shipping_method"]').val();
            var methods_meestA = [
                'meest2.warehouse',
                'meest2.courier',
                'meest2.postomat'
            ];
            if (!methods_meestA.includes(currentMethod)) {
                return $.Deferred().resolve([]).promise();
            }
            meestShippingData.src = [];
            $(this).meestAutocomplete({
                source: function (request, response) {
                    meestShippingData.getAddress(this, request).done(function () {
                        if (Array.isArray(meestShippingData.src) && meestShippingData.src.length > 0) {
                            response($.map(meestShippingData.src, function (item) {
                                let fullLabel = item['description'] ? item['description'].trim() : '';

                                return {
                                    id: item['id'] || '',
                                    label: fullLabel,
                                    value: fullLabel
                                };
                            }));
                        } else {
                            response([]);
                        }
                    });
                },
                select: function (e) {
                    this.val(e.value);
                    this.trigger('change');
                },
                class: 'dropdown-address'
            });
        }
    });
});